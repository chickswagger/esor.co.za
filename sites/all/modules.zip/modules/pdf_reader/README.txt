README.txt
==========

Usage
=====

To use pdf_reader module add a field to a content type, it can be either a File field or a Text field.

Edit display settings for that field and select Widget type: PDF Reader.

Edit settings to your taste.

Enjoy!

Additional Support
=================
For support, please create a support request for this module's project:
  http://drupal.org/project/pdf_reader

Support questions by email to the module maintainer will be simply ignored. Use the issue tracker.

====================================================================
Victor Castell, victor.castell at season.es, http://season.es